import axios from 'axios';

const rapidApiKey = '514b1cc444msh7c2e81f1dd6f54bp15edcfjsn188a075fa8d4';

// Client API configuré pour RapidAPI
const rapidApiClient = axios.create({
  headers: {
    'X-RapidAPI-Key': rapidApiKey,
    'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
  }
});

export interface Match {
  id: number;
  homeTeam: string;
  awayTeam: string;
  league: string;
  date: string;
  time: string;
  odds: {
    home: number;
    draw: number;
    away: number;
  };
  status: 'scheduled' | 'live' | 'finished';
}

export const sportsApi = {
  // Obtenir les matchs en direct
  getLiveMatches: async (): Promise<Match[]> => {
    try {
      const response = await rapidApiClient.get('https://api-football-v1.p.rapidapi.com/v3/fixtures', {
        params: { live: 'all' }
      });
      
      return response.data.response.map((match: any) => ({
        id: match.fixture.id,
        homeTeam: match.teams.home.name,
        awayTeam: match.teams.away.name,
        league: match.league.name,
        date: match.fixture.date,
        time: new Date(match.fixture.date).toLocaleTimeString(),
        odds: {
          home: match.odds?.main?.home || 1.5,
          draw: match.odds?.main?.draw || 3.0,
          away: match.odds?.main?.away || 2.0
        },
        status: 'live'
      }));
    } catch (error) {
      console.error('Error fetching live matches:', error);
      throw error;
    }
  },

  // Obtenir les matchs à venir
  getUpcomingMatches: async (league?: string): Promise<Match[]> => {
    try {
      const params: any = {
        season: '2024',
        next: '50'
      };
      
      if (league) {
        params.league = league;
      }

      const response = await rapidApiClient.get('https://api-football-v1.p.rapidapi.com/v3/fixtures', {
        params
      });

      return response.data.response.map((match: any) => ({
        id: match.fixture.id,
        homeTeam: match.teams.home.name,
        awayTeam: match.teams.away.name,
        league: match.league.name,
        date: match.fixture.date,
        time: new Date(match.fixture.date).toLocaleTimeString(),
        odds: {
          home: match.odds?.main?.home || 1.5,
          draw: match.odds?.main?.draw || 3.0,
          away: match.odds?.main?.away || 2.0
        },
        status: 'scheduled'
      }));
    } catch (error) {
      console.error('Error fetching upcoming matches:', error);
      throw error;
    }
  },

  // Obtenir les cotes pour un match spécifique
  getMatchOdds: async (fixtureId: number) => {
    try {
      const response = await rapidApiClient.get('https://api-football-v1.p.rapidapi.com/v3/odds', {
        params: { fixture: fixtureId }
      });

      return response.data.response[0]?.bookmakers[0]?.bets[0]?.values || null;
    } catch (error) {
      console.error('Error fetching odds:', error);
      throw error;
    }
  },

  // Obtenir les ligues disponibles
  getLeagues: async () => {
    try {
      const response = await rapidApiClient.get('https://api-football-v1.p.rapidapi.com/v3/leagues');
      
      return response.data.response.map((league: any) => ({
        id: league.league.id,
        name: league.league.name,
        country: league.country.name,
        logo: league.league.logo
      }));
    } catch (error) {
      console.error('Error fetching leagues:', error);
      throw error;
    }
  },

  // Obtenir les statistiques d'une équipe
  getTeamStats: async (teamId: number) => {
    try {
      const response = await rapidApiClient.get('https://api-football-v1.p.rapidapi.com/v3/teams/statistics', {
        params: {
          team: teamId,
          season: '2024'
        }
      });

      return response.data.response;
    } catch (error) {
      console.error('Error fetching team stats:', error);
      throw error;
    }
  }
};
