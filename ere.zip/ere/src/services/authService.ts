import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  sendPasswordResetEmail,
  User
} from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, getDoc, updateDoc } from 'firebase/firestore';

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  balance?: number;
  betsPlaced?: number;
}

export const authService = {
  register: async (email: string, password: string, displayName: string): Promise<UserProfile> => {
    const { user } = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(user, { displayName });
    
    // Créer le profil utilisateur dans Firestore
    const userProfile: UserProfile = {
      uid: user.uid,
      email: user.email!,
      displayName,
      balance: 1000, // Solde initial
      betsPlaced: 0
    };
    
    await setDoc(doc(db, 'users', user.uid), userProfile);
    return userProfile;
  },

  login: async (email: string, password: string) => {
    return signInWithEmailAndPassword(auth, email, password);
  },

  logout: async () => {
    return signOut(auth);
  },

  resetPassword: async (email: string) => {
    return sendPasswordResetEmail(auth, email);
  },

  updateUserProfile: async (user: User, data: Partial<UserProfile>) => {
    const updates: Partial<UserProfile> = {};
    
    if (data.displayName) {
      await updateProfile(user, { displayName: data.displayName });
      updates.displayName = data.displayName;
    }
    
    if (data.photoURL) {
      await updateProfile(user, { photoURL: data.photoURL });
      updates.photoURL = data.photoURL;
    }

    if (Object.keys(updates).length > 0) {
      await updateDoc(doc(db, 'users', user.uid), updates);
    }
  },

  getUserProfile: async (uid: string): Promise<UserProfile | null> => {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    return docSnap.exists() ? docSnap.data() as UserProfile : null;
  },

  updateBalance: async (uid: string, amount: number) => {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      balance: amount
    });
  }
};
