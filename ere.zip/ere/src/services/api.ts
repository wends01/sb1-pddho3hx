import axios from 'axios';

const api = axios.create({
  baseURL: 'https://api.your-sports-api.com/v1', // À remplacer par votre API réelle
  headers: {
    'Content-Type': 'application/json',
  },
});

export const sportsApi = {
  getEvents: async (filters?: { sport?: string; date?: string; live?: boolean }) => {
    const response = await api.get('/events', { params: filters });
    return response.data;
  },

  getBetHistory: async (userId: string) => {
    const response = await api.get(`/users/${userId}/bets`);
    return response.data;
  },

  placeBet: async (betData: any) => {
    const response = await api.post('/bets', betData);
    return response.data;
  },

  getFavorites: async (userId: string) => {
    const response = await api.get(`/users/${userId}/favorites`);
    return response.data;
  },

  toggleFavorite: async (userId: string, eventId: string) => {
    const response = await api.post(`/users/${userId}/favorites/${eventId}`);
    return response.data;
  },
};
