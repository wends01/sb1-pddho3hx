import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { firebaseConfig } from '../config/firebase.config';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

export const authService = {
  login: async (email: string, password: string) => {
    return signInWithEmailAndPassword(auth, email, password);
  },

  register: async (email: string, password: string) => {
    return createUserWithEmailAndPassword(auth, email, password);
  },

  logout: async () => {
    return signOut(auth);
  },
};
