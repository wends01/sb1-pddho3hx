import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyBmDZcrSMMe6TMRWRbQRZMl9Ry9-wn0FD0',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'blackpro-f6207.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'blackpro-f6207',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'blackpro-f6207.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '421473667987',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:421473667987:android:9b7b7b70a8b316670cb666'
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export default app;
