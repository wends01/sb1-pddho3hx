export const firebaseConfig = {
  apiKey: "AIzaSyBmDZcrSMMe6TMRWRbQRZMl9Ry9-wn0FD0",
  authDomain: "blackpro-f6207.firebaseapp.com",
  projectId: "blackpro-f6207",
  storageBucket: "blackpro-f6207.firebasestorage.app",
  messagingSenderId: "421473667987",
  appId: "1:421473667987:android:9b7b7b70a8b316670cb666",
  measurementId: process.env.VITE_FIREBASE_MEASUREMENT_ID
};
