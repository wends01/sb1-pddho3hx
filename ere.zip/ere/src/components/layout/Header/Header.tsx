import { Menu, Search, User, LogIn } from 'lucide-react';
import { NavLinks } from './NavLinks';

export function Header() {
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <button 
              className="lg:hidden p-2 hover:bg-primary-dark rounded-full transition-colors"
              aria-label="Menu"
            >
              <Menu size={24} />
            </button>
            <h1 className="text-2xl font-bold">BLACKPRO</h1>
          </div>
          
          <NavLinks />

          <div className="flex items-center gap-4">
            <button 
              className="p-2 hover:bg-primary-dark rounded-full transition-colors"
              aria-label="Search"
            >
              <Search size={20} />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary-dark hover:bg-blue-800 rounded-full transition-colors">
              <LogIn size={20} />
              <span>Login</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 rounded-full transition-colors">
              <User size={20} />
              <span>Register</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}