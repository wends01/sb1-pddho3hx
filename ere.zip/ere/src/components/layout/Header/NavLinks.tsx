export function NavLinks() {
  const links = [
    { href: '#', label: 'Sports' },
    { href: '#', label: 'Live' },
    { href: '#', label: 'Promotions' },
    { href: '#', label: 'Support' },
  ] as const;

  return (
    <div className="hidden md:flex items-center gap-6">
      <nav>
        <ul className="flex gap-6">
          {links.map(({ href, label }) => (
            <li key={label}>
              <a 
                href={href} 
                className="hover:text-blue-200 transition-colors"
              >
                {label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}