import { SportsList } from './SportsList';

export function Sidebar() {
  return (
    <aside className="hidden lg:block w-64 bg-white rounded-lg shadow-md p-4">
      <h2 className="text-lg font-semibold mb-4">Sports</h2>
      <nav>
        <SportsList />
      </nav>
    </aside>
  );
}