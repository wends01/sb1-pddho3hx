import { Trophy } from 'lucide-react';
import { FootballIcon, BasketballIcon, TennisIcon } from '../../icons';

const sports = [
  { 
    icon: FootballIcon, 
    name: 'Football',
    gradient: 'from-primary-light to-primary'
  },
  { 
    icon: BasketballIcon, 
    name: 'Basketball',
    gradient: 'from-secondary-light to-secondary'
  },
  { 
    icon: TennisIcon, 
    name: 'Tennis',
    gradient: 'from-primary to-secondary'
  },
  { 
    icon: Trophy, 
    name: 'Other Sports',
    gradient: 'from-primary-dark to-secondary-dark'
  }
] as const;

export function SportsList() {
  return (
    <ul className="space-y-3">
      {sports.map(({ icon: Icon, name, gradient }) => (
        <li key={name}>
          <a 
            href="#" 
            className="flex items-center gap-3 p-3 rounded-xl transition-all duration-300
                     hover:bg-gradient-to-r hover:shadow-md hover:scale-105 hover:text-white"
            style={{
              backgroundImage: `linear-gradient(to right, var(--${gradient}))`,
              backgroundSize: '200% 100%',
              backgroundPosition: '100% 0',
            }}
          >
            <Icon size={24} className="text-current" />
            <span className="font-medium">{name}</span>
          </a>
        </li>
      ))}
    </ul>
  );
}