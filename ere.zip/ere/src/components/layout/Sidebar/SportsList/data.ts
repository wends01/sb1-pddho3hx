import { Racket, Trophy } from 'lucide-react';
import { FootballIcon, BasketballIcon, TennisIcon } from '../../../icons';
import { Sport } from './types';

export const sports: Sport[] = [
  { icon: FootballIcon, name: 'Football', path: '/sports/football' },
  { icon: BasketballIcon, name: 'Basketball', path: '/sports/basketball' },
  { icon: TennisIcon, name: 'Tennis', path: '/sports/tennis' },
  { icon: Trophy, name: 'Other Sports', path: '/sports/others' }
];