import { Sport } from './types';

type SportItemProps = {
  sport: Sport;
};

export function SportItem({ sport: { icon: Icon, name, path } }: SportItemProps) {
  return (
    <li>
      <a 
        href={path} 
        className="flex items-center gap-3 p-2 hover:bg-gray-100 rounded-lg transition-colors"
      >
        <Icon size={20} />
        <span>{name}</span>
      </a>
    </li>
  );
}