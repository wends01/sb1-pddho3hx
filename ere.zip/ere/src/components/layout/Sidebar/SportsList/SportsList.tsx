import { sports } from './data';
import { SportItem } from './SportItem';

export function SportsList() {
  return (
    <ul className="space-y-2">
      {sports.map((sport) => (
        <SportItem key={sport.name} sport={sport} />
      ))}
    </ul>
  );
}