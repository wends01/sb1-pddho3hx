import { LucideIcon } from 'lucide-react';
import { BasketballIcon } from '../../../icons';

export type Sport = {
  icon: LucideIcon | typeof BasketballIcon;
  name: string;
  path: string;
};