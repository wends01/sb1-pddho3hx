import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from 'react-query';
import { sportsApi, Match } from '../services/sportsApi';
import { notify } from './Notifications';
import { Clock, Activity } from 'lucide-react';

export function EventsList() {
  const [showLiveOnly, setShowLiveOnly] = useState(false);
  const [selectedLeague, setSelectedLeague] = useState<string>();

  const { 
    data: liveMatches, 
    isLoading: loadingLive 
  } = useQuery('liveMatches', sportsApi.getLiveMatches, {
    refetchInterval: 30000, // Rafraîchir toutes les 30 secondes
    enabled: showLiveOnly
  });

  const { 
    data: upcomingMatches, 
    isLoading: loadingUpcoming 
  } = useQuery(
    ['upcomingMatches', selectedLeague],
    () => sportsApi.getUpcomingMatches(selectedLeague),
    {
      enabled: !showLiveOnly
    }
  );

  const matches = showLiveOnly ? liveMatches : upcomingMatches;
  const isLoading = showLiveOnly ? loadingLive : loadingUpcoming;

  const handlePlaceBet = (match: Match, type: '1' | 'X' | '2', odds: number) => {
    // TODO: Implémenter la logique de pari
    notify.success(`Pari placé sur ${match.homeTeam} vs ${match.awayTeam}`);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Événements Sportifs</h2>
        <button
          onClick={() => setShowLiveOnly(!showLiveOnly)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
            showLiveOnly
              ? 'bg-green-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {showLiveOnly ? <Activity size={20} /> : <Clock size={20} />}
          <span>{showLiveOnly ? 'En Direct' : 'À venir'}</span>
        </button>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={showLiveOnly ? 'live' : 'upcoming'}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="space-y-4"
        >
          {matches?.map((match) => (
            <motion.div
              key={match.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-lg shadow-md p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">{match.league}</span>
                <div className="flex items-center gap-2">
                  {match.status === 'live' && (
                    <span className="flex items-center gap-1 text-green-600">
                      <Activity size={16} />
                      En direct
                    </span>
                  )}
                  <span className="text-sm text-gray-600">{match.time}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="font-medium">{match.homeTeam}</h3>
                  <h3 className="font-medium">{match.awayTeam}</h3>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handlePlaceBet(match, '1', match.odds.home)}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded text-center min-w-[80px]"
                  >
                    <span className="block font-semibold">{match.odds.home}</span>
                    <span className="text-sm text-gray-600">1</span>
                  </button>
                  <button
                    onClick={() => handlePlaceBet(match, 'X', match.odds.draw)}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded text-center min-w-[80px]"
                  >
                    <span className="block font-semibold">{match.odds.draw}</span>
                    <span className="text-sm text-gray-600">X</span>
                  </button>
                  <button
                    onClick={() => handlePlaceBet(match, '2', match.odds.away)}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded text-center min-w-[80px]"
                  >
                    <span className="block font-semibold">{match.odds.away}</span>
                    <span className="text-sm text-gray-600">2</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}