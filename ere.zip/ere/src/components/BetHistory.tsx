import React from 'react';
import { motion } from 'framer-motion';
import { useQuery } from 'react-query';
import { sportsApi } from '../services/api';
import { auth } from '../services/firebase';

export function BetHistory() {
  const { data: bets, isLoading } = useQuery(
    ['betHistory', auth.currentUser?.uid],
    () => sportsApi.getBetHistory(auth.currentUser?.uid || ''),
    {
      enabled: !!auth.currentUser,
    }
  );

  if (isLoading) return <div>Loading...</div>;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-4"
    >
      <h2 className="text-xl font-semibold">Bet History</h2>
      <div className="space-y-4">
        {bets?.map((bet: any) => (
          <motion.div
            key={bet.id}
            initial={{ x: -20 }}
            animate={{ x: 0 }}
            className="bg-white rounded-lg shadow-md p-4"
          >
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">{bet.event}</p>
                <p className="text-sm text-gray-600">{bet.date}</p>
              </div>
              <div className="text-right">
                <p className={`font-bold ${bet.status === 'won' ? 'text-green-600' : 'text-red-600'}`}>
                  {bet.status === 'won' ? '+' : '-'}${bet.amount}
                </p>
                <p className="text-sm text-gray-600">Odds: {bet.odds}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
