import { Toaster, toast } from 'react-hot-toast';

export const Notifications = () => {
  return <Toaster position="top-right" />;
};

export const notify = {
  success: (message: string) => toast.success(message),
  error: (message: string) => toast.error(message),
  loading: (message: string) => toast.loading(message),
};
