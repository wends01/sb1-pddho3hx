import { LucideProps } from 'lucide-react';

export function FootballIcon({ size = 24, strokeWidth = 2, className, ...props }: LucideProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a10 10 0 0 1 0 20 10 10 0 0 1 0-20z" />
      <path d="M12 6l3.464 2v4L12 14l-3.464-2V8L12 6z" />
      <path d="M12 14v4" />
      <path d="M8.536 8l3.464 2" />
      <path d="M15.464 8l-3.464 2" />
    </svg>
  );
}
