import { LucideProps } from 'lucide-react';

export function TennisIcon({ size = 24, strokeWidth = 2, className, ...props }: LucideProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a10 10 0 0 1 0 20 10 10 0 0 1 0-20z" />
      <path d="M12 6c2 2.5 4 5 4 8s-2 5.5-4 8c-2-2.5-4-5-4-8s2-5.5 4-8z" />
      <path d="M2 12h20" />
    </svg>
  );
}
