import { LucideProps } from 'lucide-react';

export function BasketballIcon({ size = 24, strokeWidth = 2, className, ...props }: LucideProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a10 10 0 0 1 0 20" />
      <path d="M2 12h20" />
      <path d="M12 2c-2.5 2.5-5 5-5 10s2.5 7.5 5 10c2.5-2.5 5-5 5-10s-2.5-7.5-5-10z" />
    </svg>
  );
}