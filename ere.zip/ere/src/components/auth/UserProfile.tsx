import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAuthContext } from '../../contexts/AuthContext';
import { authService, UserProfile } from '../../services/authService';
import { notify } from '../Notifications';

export function UserProfileComponent() {
  const { user } = useAuthContext();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');

  useEffect(() => {
    if (user) {
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    try {
      const userProfile = await authService.getUserProfile(user.uid);
      setProfile(userProfile);
      setDisplayName(userProfile?.displayName || '');
    } catch (error: any) {
      notify.error('Erreur lors du chargement du profil');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
    if (!user) return;

    try {
      await authService.updateUserProfile(user, { displayName });
      notify.success('Profil mis à jour !');
      setEditing(false);
      loadProfile();
    } catch (error: any) {
      notify.error(error.message);
    }
  };

  const handleLogout = async () => {
    try {
      await authService.logout();
      notify.success('Déconnexion réussie');
    } catch (error: any) {
      notify.error(error.message);
    }
  };

  if (loading) {
    return <div>Chargement...</div>;
  }

  if (!profile) {
    return <div>Profil non trouvé</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white shadow-md rounded-lg p-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Mon Profil</h2>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Déconnexion
        </button>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600">Nom d'utilisateur</p>
            {editing ? (
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="mt-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            ) : (
              <p className="font-medium">{profile.displayName}</p>
            )}
          </div>
          <button
            onClick={() => {
              if (editing) {
                handleUpdateProfile();
              } else {
                setEditing(true);
              }
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            {editing ? 'Sauvegarder' : 'Modifier'}
          </button>
        </div>

        <div>
          <p className="text-gray-600">Email</p>
          <p className="font-medium">{profile.email}</p>
        </div>

        <div>
          <p className="text-gray-600">Solde</p>
          <p className="font-medium text-green-600">{profile.balance} €</p>
        </div>

        <div>
          <p className="text-gray-600">Paris placés</p>
          <p className="font-medium">{profile.betsPlaced}</p>
        </div>
      </div>
    </motion.div>
  );
}
