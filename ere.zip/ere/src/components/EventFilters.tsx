import React from 'react';
import { motion } from 'framer-motion';

const sports = ['Football', 'Basketball', 'Tennis', 'Hockey'];

interface EventFiltersProps {
  onFilterChange: (filters: { sport?: string; live?: boolean }) => void;
}

export function EventFilters({ onFilterChange }: EventFiltersProps) {
  const [selectedSport, setSelectedSport] = React.useState<string>();
  const [showLiveOnly, setShowLiveOnly] = React.useState(false);

  const handleSportChange = (sport: string) => {
    setSelectedSport(sport === selectedSport ? undefined : sport);
    onFilterChange({ sport: sport === selectedSport ? undefined : sport, live: showLiveOnly });
  };

  const handleLiveToggle = () => {
    setShowLiveOnly(!showLiveOnly);
    onFilterChange({ sport: selectedSport, live: !showLiveOnly });
  };

  return (
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="space-y-4 mb-6"
    >
      <div className="flex gap-2">
        {sports.map((sport) => (
          <motion.button
            key={sport}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleSportChange(sport)}
            className={`px-4 py-2 rounded-full ${
              selectedSport === sport
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 hover:bg-gray-200'
            }`}
          >
            {sport}
          </motion.button>
        ))}
      </div>
      
      <div className="flex items-center gap-2">
        <button
          onClick={handleLiveToggle}
          className={`px-4 py-2 rounded-full ${
            showLiveOnly
              ? 'bg-green-600 text-white'
              : 'bg-gray-100 hover:bg-gray-200'
          }`}
        >
          Live Events Only
        </button>
      </div>
    </motion.div>
  );
}
