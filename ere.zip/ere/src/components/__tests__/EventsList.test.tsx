import { render, screen } from '@testing-library/react';
import { EventsList } from '../EventsList';

describe('EventsList', () => {
  it('renders the featured events title', () => {
    render(<EventsList />);
    expect(screen.getByText('Featured Events')).toBeInTheDocument();
  });

  it('renders live events button', () => {
    render(<EventsList />);
    expect(screen.getByText('Live Events')).toBeInTheDocument();
  });

  it('renders event cards with team names', () => {
    render(<EventsList />);
    expect(screen.getByText('Manchester United')).toBeInTheDocument();
    expect(screen.getByText('Liverpool')).toBeInTheDocument();
  });

  it('renders odds buttons for each event', () => {
    render(<EventsList />);
    const oddsButtons = screen.getAllByRole('button');
    expect(oddsButtons.length).toBeGreaterThan(0);
  });
});
