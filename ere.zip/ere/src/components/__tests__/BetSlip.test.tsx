import { render, screen } from '@testing-library/react';
import { BetSlip } from '../BetSlip';

describe('BetSlip', () => {
  it('renders bet slip title', () => {
    render(<BetSlip />);
    expect(screen.getByText('Bet Slip')).toBeInTheDocument();
  });

  it('shows empty state message when no bets are selected', () => {
    render(<BetSlip />);
    expect(screen.getByText('Your bet slip is empty')).toBeInTheDocument();
  });

  it('shows stake input field', () => {
    render(<BetSlip />);
    expect(screen.getByPlaceholderText('Enter stake')).toBeInTheDocument();
  });

  it('shows disabled place bet button when empty', () => {
    render(<BetSlip />);
    const button = screen.getByText('Place Bet');
    expect(button).toBeDisabled();
  });
});
