import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Bet {
  id: number;
  eventId: number;
  selection: '1' | 'X' | '2';
  odds: number;
  teamNames: string;
}

interface BetState {
  selections: Bet[];
  stake: number;
}

const initialState: BetState = {
  selections: [],
  stake: 0,
};

export const betSlice = createSlice({
  name: 'bet',
  initialState,
  reducers: {
    addBet: (state, action: PayloadAction<Bet>) => {
      state.selections.push(action.payload);
    },
    removeBet: (state, action: PayloadAction<number>) => {
      state.selections = state.selections.filter(bet => bet.id !== action.payload);
    },
    setStake: (state, action: PayloadAction<number>) => {
      state.stake = action.payload;
    },
    clearBetSlip: (state) => {
      state.selections = [];
      state.stake = 0;
    },
  },
});

export const { addBet, removeBet, setStake, clearBetSlip } = betSlice.actions;
export default betSlice.reducer;
